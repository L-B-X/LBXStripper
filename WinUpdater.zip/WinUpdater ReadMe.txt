WINDOWS ONLY - Sorry - I do not have a Mac to develop something similar - although someone out there that does might be able to work something out...?


TO INSTALL:

Unzip WinUpdater.zip into your LBXCS_Resources folder.



TO USE:

Within Stripper - in Settings - you should now see a 'Update LBX' button.  Click this to update to latest version of Stripper.

You will need to reopen the script once the download has succeeded to run the new version.





EXTRA:

Create a shortcut to Run_Updater.bat file in the updater folder to run the updater from outside of Stripper.


