WINDOWS ONLY - Sorry - I do not have a Mac to develop something similar - although someone out there that does might be able to work something out...?


TO INSTALL:

Unzip WinUpdater.zip into your LBXCS_Resources folder.



TO USE:

Within Stripper - in Settings - you should now see a 'Update LBX' button.  Click this to update to latest version of Stripper.

You will need to reopen the script once the download has succeeded to run the new version.





EXTRA (NOT A REQUIREMENT):

You can create a batch file (simple text file with extension .bat) and place the following batch script in:

cmd.exe /K [LBXCS_resources PATH]/updater/lua.exe [LBXCS_resources PATH]/updater/lbx_updater.lua "%1"

Update [LBXCS_resources PATH] to the path of your resources folder eg:

cmd.exe /K C:/Users/Leon/AppData/Roaming/REAPER/Scripts/LBX/LBXCS_resources/updater/lua.exe C:/Users/leon/AppData/Roaming/REAPER/Scripts/LBX/LBXCS_resources/updater/lbx_updater.lua "%1"

you can then use this batch file to update stripper externally if you wish.



