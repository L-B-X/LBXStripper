require("io")
require("socket")

local https = require("ssl.https")

function script_path()
   local str = debug.getinfo(2, "S").source:sub(2)
   return str:match("(.*/)")
end

function ProcessLua(s, d)

	print('Downloading: '..d)
	local body, code, headers, status = https.request(s)
	if body then
		local dfn = lbxpath..d
		local file = io.open(dfn,"rb")
		local old
		if file then
			old = file:read("*a")
			file:close()
		end

		if not old or (body ~= old) then

			if old then
				--backup old version
				print('Backing up: '..d)
				local ffn = respath..'updater/oldversions/'..d
				local file = io.open(ffn,"wb")
				if file then
					file:write(old)
					file:close()			
				end
			end
			
			local file = io.open(dfn,"wb")
			if file then
				file:write(body)
				file:close()
			end
		else
			print('No new version')
		end
	else
		print('Unable to download: '..d)
	end
end

function ProcessZip(s, d, dp)

	print('Downloading: '..d)
	local body, code, headers, status = https.request(s)
	if body then
		local fn = lbxpath..d
		local file = io.open(fn,"wb")
		if file then
			file:write(body)
			file:close()
			print('Extracting: '..d)
			os.execute('cd '..path)
			local command
			local xx = lbxpath..dp
			if string.match(xx,'.*%s') then
				command = 'unzip.exe -oq "'..fn..'" -d "'..xx..'"'			
			else
				command = 'unzip.exe -oq "'..fn..'" -d '..xx
			end
			--print('RUNNING\n'..command)
			os.execute(command)
		end
	else
		print('Unable to download: '..d)
	end
end

path = script_path()
respath = string.match(path,'(.*[\\/]).+[\\/]')
lbxpath = string.match(respath,'(.*[\\/]).+[\\/]')

print('LBX resources path = '..respath)
print('LBX path = '..lbxpath)

local st = "https://raw.githubusercontent.com/L-B-X/LBXStripper/master/WinUpdater/lbx_dldata.txt"
print('Downloading Download Data File...')
local body, code, headers, status = https.request(st)
if body then

	local data = body
	local dltbl = {}
	for dl in string.gmatch(data,'(%[dl%].-%[/dl%])') do
		table.insert(dltbl,dl)
	end
	
	local dlx
	for i = 1, #dltbl do
	
		dlx = string.match(dltbl[i],"%[ft%](.-)\n")
		local dlsrc = string.match(dltbl[i],'%[src%](.-)\n')
		local dldest = string.match(dltbl[i],'%[dest%](.-)\n')
		local dldestpath = string.match(dltbl[i],"%[destpath%](.-)\n")
		
		dlsrc = string.sub(dlsrc,1,string.len(dlsrc)-1)
		dldest = string.sub(dldest,1,string.len(dldest)-1)
		if dldestpath then
			dldestpath = string.sub(dldestpath,1,string.len(dldestpath)-1)
		end
		
		if string.sub(dlx,1,3) == 'Lua' then
		
			ProcessLua(dlsrc, dldest)
			
		elseif string.sub(dlx,1,3) == 'Zip' then

			ProcessZip(dlsrc, dldest, dldestpath)
		
		end
	end

else
	print("Download data file couldn't be downloaded.")
end
